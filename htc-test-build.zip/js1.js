function show (name){										//это функция для кнопки 'начать регистрацию'
	alert("Ради Вашей же безопасноти убедитесь, пожалуйста, что пароль содержит минимум один специальный символ! " +
		"Я еще не научился проверять их наличие((")
	var elem = document.getElementById(name);
	if(elem)
		elem.style.display = "block";
}

function check() {											//функция для проверки корректности вводимых данных
	if(reg.pass1.value == reg.pass2.value &&				//проверяем, выполняются-ли все условия
		reg.name.value != 0 &&
		reg.pol.value != 0 &&
		reg.log.value != 0 &&
		reg.log.value.includes("@") &&
		(reg.pass1.value).length >= 6 &&
		(reg.pass1.value.toUpperCase() != reg.pass1.value && 
		reg.pass1.value.toLowerCase() != reg.pass1.value) &&
		(reg.pass1.value.search(/[0-9]/) > 0) &&
		reg.pass1.value == reg.pass2.value) {
		alert("Регистрация прошла успешно")
	}														//если какое-то условие не выполняется, начинаем проверку..
	else if (reg.pass1.value != reg.pass2.value) {			//выдаем алерт-бокс, если не совпадают пароли...
        alert("Пароли не совпадают")
    }
    else if ((reg.pass1.value).length < 6) {				//...если пароль слишком короткий...
        alert("Длина пароля должна быть больше 6 символов")
    }
	else if (reg.pass1.value.search(/[0-9]/) < 0) {			//...если пароль не содержит цифр...
        alert("Пароль должен содержать минимум одну цифру")
    }
	else if (reg.pass1.value.toUpperCase() == reg.pass1.value || reg.pass1.value.toLowerCase() == reg.pass1.value) {
        alert("Пароль должен содержать буквы разных регистров")  //если пароль содержит буквы только одного регистра...
    }
	else if (!reg.log.value.includes("@")){					//...если логин не является почтой...
		alert("Некорректный Логин(используйте Вашу почту)")
	}
	else {													//...и наконец, если пользователь ввел не все значения
        alert("Заполнены не все поля")
    }
}